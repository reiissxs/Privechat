# PRIVE CHAT — versão de entrada redesenhada

## Hospedar na Vercel

1. Extraia o ZIP.
2. No painel da Vercel, escolha **Add New → Project**.
3. Importe um repositório GitHub contendo estes arquivos ou use a Vercel CLI dentro desta pasta.
4. Para este HTML estático, não é necessário comando de build nem instalar dependências.
5. Faça o deploy e teste no celular e no desktop.

## Escopo desta entrega

- Redesign da página inicial, responsivo para desktop e celular.
- Mantém a identidade original vinho, dourado e creme do PRIVE CHAT.
- Mantém os IDs e os fluxos existentes para entrar, confirmação de 18 anos, chamada, busca e painel no HTML recebido.
- O restante do aplicativo não foi refeito.

## Importante antes de uso público

Este pacote é uma entrega de front-end. Ele não configura nem conecta automaticamente Neon, autenticação segura no servidor, armazenamento compartilhado de moedas ou matchmaking real. A tela de administrador presente no HTML original não deve ser considerada segura para produção até que o login e as permissões sejam validados no servidor. A busca/chamada original também continua sendo uma simulação com vídeo local, não uma conexão entre duas pessoas reais.
